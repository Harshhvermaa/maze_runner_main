import 'package:flutter/material.dart';
import 'package:maze_runner/screens/frontScreen.dart';
import 'package:maze_runner/screens/web_first_screen.dart';

class CheckScreen extends StatelessWidget {
  const CheckScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MediaQuery.of(context).size.width > 500
          ? const WebFirstScreen()
          : const FrontScreen(),
    );
  }
}
