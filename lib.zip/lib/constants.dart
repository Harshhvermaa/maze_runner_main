const double spacing = 25;
const double height = 500;
const double width = 500;
